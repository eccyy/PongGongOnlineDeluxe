﻿namespace PongGongOnlineDeluxe.Library
{
    public enum PacketType
    {
        Login
    }
}
